import { Outlet } from "react-router-dom"
import AuthToast from "../components/AuthToast"

export default function AuthLayout() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-slate-100 px-4">
      <div className="w-full max-w-sm bg-white rounded-xl shadow-xl p-6">
        <AuthToast />
        <Outlet />
      </div>
    </div>
  )
}