import { NavLink, Outlet } from "react-router-dom"
import LogoutButton from "../components/LogoutButton"

export default function AdminLayout() {
  return (
    <div className="min-h-screen flex">

      <aside className="w-64 bg-slate-900 text-white p-4 space-y-3">
        <h2 className="text-xl font-bold mb-4">Admin Panel</h2>

        <NavLink end to="/app/admin" className="block hover:text-green-400">
         Home
        </NavLink>

        <NavLink to="/app/admin/owners" className="block hover:text-green-400">
          Owner Approvals
        </NavLink>

        <NavLink to="/app/admin/turfs" className="block hover:text-green-400">
          Turfs
        </NavLink>

        <NavLink to="/app/admin/payments" className="block hover:text-green-400">
          Payments
        </NavLink>

        <NavLink to="/app/admin/payouts" className="block hover:text-green-400">
          Payouts
        </NavLink>

        <div className="pt-4 border-t border-slate-700">
          <LogoutButton />
        </div>
      </aside>

      <main className="flex-1 bg-gray-100 p-6 overflow-y-auto">
        <Outlet />
      </main>

    </div>
  )
}