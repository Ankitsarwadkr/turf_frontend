import { NavLink, Outlet } from "react-router-dom"
import LogoutButton from "../components/LogoutButton"


const IconHome = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path d="M3 10L12 3l9 7v10a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z"/>
  </svg>
)

const IconTurf = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <rect x="3" y="4" width="18" height="16" rx="2"/>
    <path d="M3 10h18"/>
  </svg>
)

const IconBookings = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <rect x="3" y="4" width="18" height="16" rx="2"/>
    <path d="M8 2v4M16 2v4M3 10h18"/>
  </svg>
)

const IconEarnings = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <path d="M12 1v22M17 5c0-2-3-4-5-2s1 4 3 5 4 3 2 5-5 1-5-1"/>
  </svg>
)

const IconSettings = () => (
  <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="3"/>
    <path d="M19.4 15a7.9 7.9 0 0 0 .1-6l2-1.5-2-3.5-2.3 1a8 8 0 0 0-5.8-2l-.3-2.5h-4l-.3 2.5a8 8 0 0 0-5.8 2l-2.3-1-2 3.5 2 1.5a8 8 0 0 0 0 6l-2 1.5 2 3.5 2.3-1a8 8 0 0 0 5.8 2l.3 2.5h4l.3-2.5a8 8 0 0 0 5.8-2l2.3 1 2-3.5z"/>
  </svg>
)

const deskItem = "block px-4 py-3 text-sm font-semibold tracking-wide hover:bg-slate-800"

const deskActive =
  "bg-slate-800"

const mobItem = "flex-1 flex flex-col items-center justify-center text-[10px] uppercase tracking-wide py-2 border-r border-slate-700"
const mobActive = "text-white font-bold"
const mobIdle   = "text-slate-400"

export default function OwnerLayout() {
  return (
    <div className="min-h-screen bg-slate-100 flex md:flex-row flex-col">

      {/* Desktop Sidebar */}
      <aside className="hidden md:flex w-72 bg-slate-900 text-slate-200 flex-col border-r border-slate-700">
        <div className="h-14 flex items-center px-4 font-bold border-b border-slate-700">
          Turf OS
        </div>

        <nav className="flex-1 p-2 space-y-1">
          <NavLink to="/app/owner" end
            className={({isActive})=>`${deskItem} ${isActive && deskActive}`}>
            Home
          </NavLink>
          <NavLink to="/app/owner/turfs"
            className={({isActive})=>`${deskItem} ${isActive && deskActive}`}>
            Turfs
          </NavLink>
          <NavLink to="/app/owner/bookings"
            className={({isActive})=>`${deskItem} ${isActive && deskActive}`}>
            Bookings
          </NavLink>
          <NavLink to="/app/owner/earnings"
            className={({isActive})=>`${deskItem} ${isActive && deskActive}`}>
            Earnings
          </NavLink>
          <NavLink to="/app/owner/settings"
            className={({isActive})=>`${deskItem} ${isActive && deskActive}`}>
            Settings
          </NavLink>
        </nav>
      </aside>

      {/* Content Area */}
      <main className="flex-1 flex flex-col">

        <header className="h-14 bg-white border-b flex items-center justify-between px-4">
          <div className="font-semibold text-sm">Owner Panel</div>
          <LogoutButton />
        </header>

        {/* IMPORTANT: bottom padding so bar never hides content */}
        <div className="flex-1 p-4 pb-24 md:pb-4 overflow-x-hidden">
          <Outlet />
        </div>
      </main>

      {/* Mobile Bottom OS Bar */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 h-20 bg-slate-900 border-t border-slate-700 flex z-40">

        <NavLink to="/app/owner" end
          className={({isActive})=>`${mobItem} ${isActive?mobActive:mobIdle}`}>
          <IconHome/>
          <span>Home</span>
        </NavLink>

        <NavLink to="/app/owner/turfs"
          className={({isActive})=>`${mobItem} ${isActive?mobActive:mobIdle}`}>
        <IconTurf/>
          <span>Turfs</span>
        </NavLink>

        <NavLink to="/app/owner/bookings"
          className={({isActive})=>`${mobItem} ${isActive?mobActive:mobIdle}`}>
          <IconBookings/>
          <span>Bookings</span>
        </NavLink>

        <NavLink to="/app/owner/earnings"
          className={({isActive})=>`${mobItem} ${isActive?mobActive:mobIdle}`}>
          <IconEarnings/>
          <span>Earnings</span>
        </NavLink>

        <NavLink to="/app/owner/settings"
          className={({isActive})=>`${mobItem} ${isActive?mobActive:mobIdle}`}>
          <IconSettings/>
          <span>Settings</span>
        </NavLink>

      </nav>
    </div>
  )
}