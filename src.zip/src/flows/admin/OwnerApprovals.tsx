import { useEffect, useState } from "react"
import { fetchPendingOwners, approveOwner, rejectOwner } from "../../engine/adminEngine"

export default function OwnerApprovals() {
  const [owners, setOwners] = useState<any[]>([])
  const [processingId, setProcessingId] = useState<number | null>(null)
  const [reasons, setReasons] = useState<Record<number, string>>({})
  const [confirm, setConfirm] = useState<{type:"approve"|"reject"|null,id:number|null}>({type:null,id:null})

  useEffect(() => {
    fetchPendingOwners().then(r => setOwners(r.data))
  }, [])

  const openApprove = (id:number)=> setConfirm({type:"approve",id})
  const openReject  = (id:number)=> setConfirm({type:"reject",id})

  const execute = async () => {
  const id = confirm.id!
  const type = confirm.type!

  if (type === "reject" && !reasons[id]?.trim()) {
    alert("Rejection reason is required")
    return
  }

  setProcessingId(id)

  if (type === "approve") {
    await approveOwner(id)
  } else {
    await rejectOwner(id, reasons[id])
  }

  setOwners(o => o.filter(x => x.id !== id))
  setReasons(r => ({ ...r, [id]: "" }))
  setConfirm({ type:null, id:null })
  setProcessingId(null)
}
  return (
    <div className="p-4">
      <h2 className="text-xl font-semibold mb-4">Pending Owner Approvals</h2>

      <table className="w-full border-collapse text-sm">
        <thead className="bg-slate-100">
          <tr>
            <th className="p-2 text-left">Name</th>
            <th className="p-2 text-left">Email</th>
            <th className="p-2">Mobile</th>
            <th className="p-2">₹</th>
            <th className="p-2">Documents</th>
            <th className="p-2">Reject Reason</th>
            <th className="p-2">Action</th>
          </tr>
        </thead>

        <tbody>
          {owners.map(o=>(
            <tr key={o.id} className="border-b hover:bg-slate-50">
              <td className="p-2">{o.name}</td>
              <td className="p-2">{o.email}</td>
              <td className="p-2">{o.mobileNo}</td>
              <td className="p-2 text-center">₹{o.subscriptionAmount}</td>

              <td className="p-2 text-center">
                {o.documents.map((d:any)=>(
                  <a key={d.filePath}
                     href={`http://localhost:8080${d.filePath}`}
                     target="_blank"
                     className="block text-blue-600 underline">
                    View
                  </a>
                ))}
              </td>

              <td className="p-2">
                <input
                  value={reasons[o.id]||""}
                  onChange={e=>setReasons(r=>({...r,[o.id]:e.target.value}))}
                  className="border px-2 py-1 w-40 rounded"/>
              </td>

              <td className="p-2">
                <div className="flex gap-2">
                  <button disabled={processingId===o.id}
                    onClick={()=>openApprove(o.id)}
                    className="bg-green-600 text-white px-3 py-1 rounded">
                    Approve
                  </button>

                  <button disabled={processingId===o.id}
                    onClick={()=>openReject(o.id)}
                    className="bg-red-600 text-white px-3 py-1 rounded">
                    Reject
                  </button>
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {confirm.type && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white p-4 rounded-lg w-80">
            <div className="font-semibold mb-2">
              {confirm.type==="approve" ? "Approve Owner?" : "Reject Owner?"}
            </div>

            <div className="text-sm mb-4">
              {confirm.type==="approve"
                ? "Grant dashboard access?"
                : "This action is permanent."}
            </div>

            <div className="flex justify-end gap-2">
              <button onClick={()=>setConfirm({type:null,id:null})}
                      className="border px-3 py-1 rounded">Cancel</button>
              <button onClick={execute}
                      className={`px-3 py-1 rounded text-white ${
                        confirm.type==="approve"?"bg-green-600":"bg-red-600"
                      }`}>
                Confirm
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}