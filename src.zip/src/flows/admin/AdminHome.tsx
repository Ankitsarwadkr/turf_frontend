export default function AdminHome() {
  return (
    <div>
      <h2>Admin Home</h2>
      <p>Select a section from the admin panel.</p>
    </div>
  )
}