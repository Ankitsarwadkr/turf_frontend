
import LogoutButton from "../../components/LogoutButton"

export default function OwnerDashboard(){
    return (
        <div>
            <h1>Owner Dashboard</h1>
            <LogoutButton/>
        </div>
    )
}