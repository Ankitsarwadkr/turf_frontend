import { useParams, useNavigate } from "react-router-dom"
import { useEffect, useState } from "react"
import { getTurfById } from "../../engine/ownerEngine"

type TurfImage = {
  id: number
  url: string
}

type Turf = {
  id: number
  name: string
  address: string
  mapUrl: string
  locality: string
  city: string
  description: string
  amenities: string
  turfType: string
  available: boolean
  images: TurfImage[]
  createdAt: string
}

export default function OwnerTurfManage() {
  const { turfId } = useParams()
  const nav = useNavigate()

  const [turf, setTurf] = useState<Turf | null>(null)
  const [activeImage, setActiveImage] = useState(0)

  useEffect(() => {
    getTurfById(Number(turfId)).then(r => setTurf(r.data))
  }, [turfId])

  if (!turf) return <div className="p-4">Loading turf…</div>

  const images = turf.images || []

  return (
    <div className="max-w-6xl mx-auto space-y-6">

      <div className="bg-white border rounded-xl p-6">
        <div className="text-2xl font-semibold">{turf.name}</div>
        <div className="text-sm text-gray-500">{turf.locality}, {turf.city}</div>

        <div className="mt-4 flex gap-3">
          <span className={`px-3 py-1 text-xs rounded-full ${
            turf.available ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"
          }`}>
            {turf.available ? "LIVE" : "HIDDEN"}
          </span>
          <span className="text-xs px-3 py-1 rounded-full border">{turf.turfType}</span>
        </div>
      </div>

      <div className="bg-white border rounded-xl p-4 flex gap-3">
        <button onClick={() => nav(`/app/owner/turfs/${turf.id}/edit`)} className="border px-4 py-2 rounded">
          Edit Details
        </button>
        <button onClick={() => nav(`/app/owner/turfs/${turf.id}/images`)} className="border px-4 py-2 rounded">
          Add Photos
        </button>
      </div>

      <div className="bg-white border rounded-xl p-6 space-y-3">
        <div className="font-semibold">Description</div>
        <div className="text-sm">{turf.description}</div>

        <div className="grid grid-cols-2 gap-4 text-sm mt-4">
          <div><div className="text-gray-500">Amenities</div>{turf.amenities}</div>
          <div><div className="text-gray-500">Address</div>{turf.address}</div>
        </div>

        <a href={turf.mapUrl} target="_blank" className="inline-block mt-3 text-blue-600 underline text-sm">
          Open in Google Maps
        </a>
      </div>

      <div className="bg-white border rounded-xl p-6 space-y-4">
        <div className="font-semibold">Photos</div>

        {images.length > 0 && (
          <>
            <img
              src={`http://localhost:8080${images[activeImage].url}`}
              className="w-full h-80 object-cover rounded border"
            />

            <div className="flex gap-3 overflow-x-auto">
              {images.map((img, i) => (
                <img
                  key={img.id}
                  onClick={() => setActiveImage(i)}
                  src={`http://localhost:8080${img.url}`}
                  className={`h-20 w-28 object-cover rounded border cursor-pointer ${
                    i === activeImage ? "ring-2 ring-slate-900" : "opacity-60"
                  }`}
                />
              ))}
            </div>
          </>
        )}

        {images.length === 0 && <div className="text-sm text-gray-400">No photos uploaded yet.</div>}
      </div>
    </div>
  )
}