import { useParams, useNavigate } from "react-router-dom"
import { useEffect, useState, useMemo } from "react"
import { getTurfById, updateTurf } from "../../engine/ownerEngine"
import FormField from "../../components/FormField"
import { useToastStore } from "../../store/toastStore"

export default function EditTurfPage() {
  const { turfId } = useParams()
  const nav = useNavigate()
  const push=useToastStore(s=> s.push)

  const [turf, setTurf] = useState<any>(null)
  const [form, setForm] = useState<any>(null)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    getTurfById(Number(turfId)).then(r => {
      setTurf(r.data)
      setForm(r.data)
    })
  }, [turfId])

  const dirty = useMemo(() => JSON.stringify(form) !== JSON.stringify(turf), [form, turf])

  const valid =
    form &&
    form.name?.length >= 3 &&
    form.city?.length >= 2 &&
    form.address?.length >= 5 &&
    form.turfType?.length >= 2 &&
    (!form.mapUrl || /^https?:\/\//.test(form.mapUrl))

  if (!form) return <div className="p-6">Loading…</div>

  const save = async () => {
    if (!dirty || !valid || saving) return
    setSaving(true)
    try {
      await updateTurf(turf.id, form)
     push("success","Turf updated successfully")
      nav(-1)
    } catch (e: any) {
      push("error", e.response?.data?.message || "Update failed")
      setSaving(false)
    }
  }

  return (
    <div className="max-w-3xl mx-auto p-6 space-y-4">

    
      <div className="text-xl font-semibold">Edit Turf</div>

      <FormField label="Turf Name">
        <input
          value={form.name}
          onChange={e => setForm({ ...form, name: e.target.value })}
          className="w-full border p-2 rounded text-sm"
        />
      </FormField>

      <FormField label="Address">
        <input
          value={form.address}
          onChange={e => setForm({ ...form, address: e.target.value })}
          className="w-full border p-2 rounded text-sm"
        />
      </FormField>

      <FormField label="Locality">
        <input
          value={form.locality}
          onChange={e => setForm({ ...form, locality: e.target.value })}
          className="w-full border p-2 rounded text-sm"
        />
      </FormField>

      <FormField label="City">
        <input
          value={form.city}
          onChange={e => setForm({ ...form, city: e.target.value })}
          className="w-full border p-2 rounded text-sm"
        />
      </FormField>

      <FormField label="Turf Type">
        <input
          value={form.turfType}
          onChange={e => setForm({ ...form, turfType: e.target.value })}
          className="w-full border p-2 rounded text-sm"
        />
      </FormField>

      <FormField label="Description">
        <textarea
          value={form.description}
          onChange={e => setForm({ ...form, description: e.target.value })}
          className="w-full border p-2 rounded text-sm"
        />
      </FormField>

      <FormField label="Amenities">
        <input
          value={form.amenities}
          onChange={e => setForm({ ...form, amenities: e.target.value })}
          className="w-full border p-2 rounded text-sm"
        />
      </FormField>

      <FormField label="Google Map URL">
        <input
          value={form.mapUrl}
          onChange={e => setForm({ ...form, mapUrl: e.target.value })}
          className="w-full border p-2 rounded text-sm"
        />
      </FormField>

      <div className="flex items-center gap-2 text-sm">
        <input
          type="checkbox"
          checked={form.available}
          onChange={e => setForm({ ...form, available: e.target.checked })}
        />
        <span>Accept Bookings</span>
      </div>

      <div className="flex justify-end gap-3 pt-4">
        <button onClick={() => nav(-1)} className="border px-4 py-2 rounded">
          Cancel
        </button>
        <button
          disabled={!dirty || !valid || saving}
          onClick={save}
          className="bg-black text-white px-4 py-2 rounded disabled:opacity-40"
        >
          {saving ? "Saving..." : "Save Changes"}
        </button>
      </div>
    </div>
  )
}