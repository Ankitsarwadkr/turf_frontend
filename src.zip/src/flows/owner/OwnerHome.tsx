export default function OwnerHome() {
  return (
    <div className="max-w-4xl">

      <h1 className="text-xl font-semibold mb-4">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

        <div className="bg-white border border-slate-300 p-4">
          <div className="text-sm text-gray-500">Upcoming Bookings</div>
          <div className="font-mono text-2xl mt-2">10</div>
        </div>

        <div className="bg-white border border-slate-300 p-4">
          <div className="text-sm text-gray-500">Weekly Earnings</div>
          <div className="font-mono text-2xl mt-2">65,800</div>
        </div>

        <div className="bg-white border border-slate-300 p-4">
          <div className="text-sm text-gray-500">Total Turfs</div>
          <div className="font-mono text-2xl mt-2">2</div>
        </div>

      </div>

      <div className="mt-6 text-sm text-gray-500">
        Metrics will activate once booking & settlement modules go live.
      </div>

    </div>
  )
}