import { useParams, useNavigate } from "react-router-dom"
import { useEffect, useState, useCallback } from "react"
import { getTurfById, addTurfImages, deleteTurfImage } from "../../engine/ownerEngine"
import { useToastStore } from "../../store/toastStore"

type TurfImage = {
  id: number
  url: string
}

export default function ManageTurfImages() {
  const { turfId } = useParams()
  const nav = useNavigate()
  const push = useToastStore(s => s.push)

  const tid = turfId && !isNaN(Number(turfId)) ? Number(turfId) : null

  const [images, setImages] = useState<TurfImage[]>([])
  const [files, setFiles] = useState<File[]>([])
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    if (!tid) return
    try {
      const r = await getTurfById(tid)
      const list = Array.isArray(r.data.images) ? r.data.images : []
      setImages(list)
    } catch {
      push("error", "Failed to load images")
    }
  }, [tid, push])

  useEffect(() => { load() }, [load])

  const upload = async () => {
    if (!tid || loading || files.length === 0) return
    setLoading(true)
    try {
      await addTurfImages(tid, files)
      push("success", "Images uploaded")
      setFiles([])
      await load()
    } catch {
      push("error", "Upload failed")
    }
    setLoading(false)
  }

  const remove = async (id: number) => {
    if (!tid) return
    if (!confirm("Delete this image?")) return
    try {
      await deleteTurfImage(tid, id)
      push("success", "Image deleted")
      await load()
    } catch {
      push("error", "Delete failed")
    }
  }

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-4">

      <div className="flex justify-between items-center">
        <div className="text-xl font-semibold">Manage Photos</div>
        <button onClick={() => nav(-1)} className="border px-3 py-1 rounded">Back</button>
      </div>

      {images.length === 0 && (
        <div className="text-sm opacity-60">No images uploaded yet.</div>
      )}

      <div className="grid grid-cols-4 gap-3">
        {images.map(img => (
          <div key={img.id} className="relative group">
            <img
              src={`http://localhost:8080${img.url}`}
              className="h-32 w-full object-cover rounded border"
            />
            <button
              onClick={() => remove(img.id)}
              className="absolute top-1 right-1 bg-black/70 text-white px-2 rounded hidden group-hover:block"
            >
              ✕
            </button>
          </div>
        ))}
      </div>

      <input
        type="file"
        multiple
        accept="image/*"
        onChange={e => setFiles(Array.from(e.target.files || []))}
      />

      <button
        disabled={loading || files.length === 0}
        onClick={upload}
        className="bg-black text-white px-4 py-2 rounded disabled:opacity-40"
      >
        {loading ? "Uploading..." : "Upload Images"}
      </button>

    </div>
  )
}