import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { getMyTurfs, deleteTurf } from "../../engine/ownerEngine"
import CreateTurf from "./CreateTurf"

type TurfRow = {
  id: number
  name: string
  city: string
  turfType: string
  bookingEnabled: boolean
  primaryImage?: string
  createdAt: string
}

export default function OwnerTurfs() {
  const [rows, setRows] = useState<TurfRow[]>([])
  const [openCreate, setOpenCreate] = useState(false)
  const nav = useNavigate()

  useEffect(() => {
    getMyTurfs().then(r => setRows(r.data))
  }, [])

  useEffect(() => {
    document.body.style.overflow = openCreate ? "hidden" : ""
  }, [openCreate])

  const remove = async (id: number) => {
    if (!confirm("Delete this turf permanently?")) return
    await deleteTurf(id)
    setRows(r => r.filter(x => x.id !== id))
  }

  return (
    <>
      <div className="max-w-6xl">

        <div className="flex justify-between items-center mb-4">
          <h1 className="text-xl font-semibold">My Turfs</h1>
          <button
            onClick={() => setOpenCreate(true)}
            className="bg-slate-900 text-white px-4 py-2 rounded-lg">
            + Add Turf
          </button>
        </div>

        {rows.length === 0 && (
          <div className="bg-white border rounded-xl p-10 text-center text-sm text-gray-500">
            No turfs yet. Add your first turf to start accepting bookings.
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {rows.map(t => (
            <div key={t.id} className="bg-white border border-slate-300 rounded-lg shadow-sm">

              {t.primaryImage && (
                <img
                  src={`http://localhost:8080${t.primaryImage}`}
                  className="h-36 w-full object-cover border-b"
                />
              )}

              <div className="p-4 space-y-1">
                <div className="flex justify-between items-start">
                  <div className="text-[11px] text-slate-400 font-mono">ID #{t.id}</div>
                  <span className={`text-[10px] font-mono px-2 py-1 rounded border ${
                    t.bookingEnabled
                      ? "border-green-500 text-green-700"
                      : "border-red-500 text-red-600"
                  }`}>
                    {t.bookingEnabled ? "BOOKING ON" : "BOOKING OFF"}
                  </span>
                </div>

                <div className="font-semibold text-sm text-slate-900">{t.name}</div>

                <div className="text-xs text-gray-500">
                  {t.city} • {t.turfType}
                </div>

                <div className="flex gap-2 pt-3">
                  <button
                    onClick={() => nav(`/app/owner/turfs/${t.id}`)}
                    className="flex-1 border border-slate-400 rounded py-1 text-xs font-medium">
                    Manage
                  </button>

                  <button
                    onClick={() => remove(t.id)}
                    className="flex-1 border border-red-500 text-red-600 rounded py-1 text-xs font-medium">
                    Delete
                  </button>
                </div>
              </div>

            </div>
          ))}
        </div>
      </div>

      {openCreate && (
        <CreateTurf
          onClose={() => setOpenCreate(false)}
          onCreated={() => getMyTurfs().then(r => setRows(r.data))}
        />
      )}
    </>
  )
}