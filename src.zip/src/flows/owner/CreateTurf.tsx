import { useState } from "react"
import { addTurf } from "../../engine/ownerEngine"
import FormField from "../../components/FormField"
import { validateTurfForm } from "../../shared/validators"
import { useToastStore } from "../../store/toastStore"

export default function CreateTurf({
  onClose,
  onCreated
}: {
  onClose: () => void
  onCreated: () => void
}) {
const push=useToastStore(s=>s.push)

  const [form, setForm] = useState({
    name: "", address: "", locality: "", mapUrl: "", city: "",
    description: "", amenities: "", turfType: "", available: true
  })

  const [images, setImages] = useState<File[]>([])
  const [errors, setErrors] = useState<any>({})
  const [loading, setLoading] = useState(false)

 

  const submit = async () => {
    const e = validateTurfForm({ ...form, images })
    if (Object.keys(e).length) {
      setErrors(e)
      return
    }

    const fd = new FormData()

        fd.append("name", form.name)
        fd.append("address", form.address)
        fd.append("locality", form.locality)
        fd.append("mapUrl", form.mapUrl)
        fd.append("city", form.city)
        fd.append("description", form.description)
        fd.append("amenities", form.amenities)
        fd.append("turfType", form.turfType)
        fd.append("available", form.available ? "1" : "0") 

        images.forEach(i => fd.append("images", i))

    setLoading(true)
    try {
      await addTurf(fd)
        push("success","Turf added successfully")
        setTimeout(() => {
        onCreated()
        onClose()
        }, 800)
    } catch (err: any) {
      push("error", err.response?.data?.message || "Create failed")
}
    setLoading(false)
  }

  return (
  <div className="fixed inset-0 bg-black/40 z-[9999] grid place-items-center">

    <div className="bg-white border border-slate-400 w-[95vw] max-w-xl max-h-[90vh] flex flex-col overflow-hidden">

      {/* HEADER */}
      <div className="p-4 border-b text-lg font-semibold">
        Create Turf
      </div>

      {/* BODY (SCROLL AREA) */}
      <div className="flex-1 overflow-y-auto p-4 space-y-3">

        {[
          ["name","Turf Name"],["address","Address"],["locality","Locality"],
          ["mapUrl","Google Map URL"],["city","City"],["turfType","Turf Type"],
          ["amenities","Amenities"]
        ].map(([k,label])=>(
          <FormField key={k} label={label} error={errors[k]}>
            <input
              className="w-full border p-2 rounded"
              value={(form as any)[k]}
              onChange={e=>setForm({...form,[k]:e.target.value})}
            />
          </FormField>
        ))}

        <FormField label="Description">
          <textarea
            className="w-full border p-2 rounded"
            value={form.description}
            onChange={e=>setForm({...form,description:e.target.value})}
          />
        </FormField>

        <FormField label="Images" error={errors.images}>
          <input
            type="file"
            multiple
            accept="image/*"
            onChange={e => {
                const files = Array.from(e.target.files || [])
                setImages(prev => [...prev, ...files])
                e.target.value = ""
            }}
        />
        </FormField>

        {images.length>0 && (
          <div className="grid grid-cols-4 gap-2">
            {images.map((img,i)=>(
              <div key={i} className="relative group">
                <img
                  src={URL.createObjectURL(img)}
                  className="h-20 w-full object-cover rounded border"
                />
                <button
                  onClick={()=>setImages(x=>x.filter((_,ix)=>ix!==i))}
                  className="absolute top-1 right-1 bg-black/70 text-white rounded-full px-1 hidden group-hover:block"
                >
                  ✕
                </button>
              </div>
            ))}
          </div>
        )}

      </div>

      {/* FOOTER */}
      <div className="border-t p-4 flex justify-end gap-2 bg-white">
        <button onClick={onClose} className="border px-4 py-2 rounded">
          Cancel
        </button>

        <button
          disabled={loading}
          onClick={submit}
          className="bg-slate-900 text-white px-4 py-2 rounded disabled:opacity-40"
        >
          {loading ? "Saving..." : "Create"}
        </button>
      </div>

    </div>
  </div>
)}