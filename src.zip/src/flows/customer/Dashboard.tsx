import LogoutButton from "../../components/LogoutButton"

export default function CustomerDashboard()
{
    return (
        <div>
            <h1>Customer dashboard</h1>
            <LogoutButton/>
        </div>
    )
}