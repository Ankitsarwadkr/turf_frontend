import { useState, useEffect } from "react"
import { registerCustomer } from "../../engine/authEngine"
import { useNavigate } from "react-router-dom"
import { validateRegisterCustomer } from "../../shared/validators"
import { useAuthStore } from "../../store/authStore"
import FormField from "../../components/FormField"

export default function RegisterCustomer() {
  const nav = useNavigate()
  const { loading, clearMessages } = useAuthStore()

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    mobileNo: ""
  })

  const [fieldErrors, setFieldErrors] = useState<any>({})

  useEffect(() => clearMessages(), [])

  // CHANGE #1 — clear field error while typing
  const set = (k: any, v: any) => {
    setForm(f => ({ ...f, [k]: v }))
    setFieldErrors((e: any) => ({ ...e, [k]: null }))
  }

  // CHANGE #2 — wrap API in try/catch
  const submit = async () => {
    clearMessages()
    setFieldErrors({})

    const err = validateRegisterCustomer(form)
    if (err) return setFieldErrors(err)

    try {
      await registerCustomer(form)
      setTimeout(() => nav("/auth/login"), 1200)
    } catch {}
  }

  return (
    <div>
      <h2 className="mb-4">Register</h2>

      {/* CHANGE #3 — controlled inputs (value=...) */}

      <FormField label="Name" error={fieldErrors.name}>
        <input
          value={form.name}
          onChange={e => set("name", e.target.value)}
          className="w-full border p-2"
        />
      </FormField>

      <FormField label="Email" error={fieldErrors.email}>
        <input
          value={form.email}
          onChange={e => set("email", e.target.value)}
          className="w-full border p-2"
        />
      </FormField>

      <FormField label="Password" error={fieldErrors.password}>
        <input
          type="password"
          value={form.password}
          onChange={e => set("password", e.target.value)}
          className="w-full border p-2"
        />
      </FormField>

      <FormField label="Mobile" error={fieldErrors.mobileNo}>
        <input
          value={form.mobileNo}
          onChange={e => set("mobileNo", e.target.value)}
          className="w-full border p-2"
        />
      </FormField>

      <button
        disabled={loading}
        onClick={submit}
        className="w-full bg-black text-white py-2 rounded mt-2"
      >
        {loading ? "Processing..." : "Create Account"}
      </button>
    </div>
  )
}