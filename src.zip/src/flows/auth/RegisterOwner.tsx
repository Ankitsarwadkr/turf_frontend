import { useState, useEffect } from "react"
import { registerOwner } from "../../engine/authEngine"
import { useNavigate } from "react-router-dom"
import { validateRegisterOwner } from "../../shared/validators"
import { useAuthStore } from "../../store/authStore"
import FormField from "../../components/FormField"

export default function RegisterOwner() {
  const nav = useNavigate()
  const { loading, clearMessages } = useAuthStore()

  const [form, setForm] = useState({
    name: "",
    email: "",
    password: "",
    mobileNo: "",
    subscriptionAmount: "",
    docType: "",
    document: null as File | null
  })

  const [fieldErrors, setFieldErrors] = useState<any>({})

  useEffect(() => clearMessages(), [])

  const set = (k: keyof typeof form, v: any) => {
  setForm(f => ({ ...f, [k]: v }))
  setFieldErrors((e: Record<string, string | null>) => ({ ...e, [k]: null }))
}

  const submit = async () => {
    clearMessages()
    setFieldErrors({})

    const err = validateRegisterOwner({
      ...form,
      subscriptionAmount: Number(form.subscriptionAmount)
    })

    if (err) return setFieldErrors(err)

    const fd = new FormData()

    Object.entries(form).forEach(([k, v]) => {
      if (k === "subscriptionAmount") {
        fd.append(k, String(Number(v)))
      } else {
        fd.append(k, v as any)
      }
    })

    try {
      await registerOwner(fd)
      setTimeout(() => nav("/auth/pending"), 1200)
    } catch {}
  }

  return (
    <div>
      <h2 className="mb-4">Register as Owner</h2>

      <FormField label="Name" error={fieldErrors.name}>
        <input value={form.name} onChange={e => set("name", e.target.value)} className="w-full border p-2"/>
      </FormField>

      <FormField label="Email" error={fieldErrors.email}>
        <input value={form.email} onChange={e => set("email", e.target.value)} className="w-full border p-2"/>
      </FormField>

      <FormField label="Password" error={fieldErrors.password}>
        <input type="password" value={form.password} onChange={e => set("password", e.target.value)} className="w-full border p-2"/>
      </FormField>

      <FormField label="Mobile" error={fieldErrors.mobileNo}>
        <input value={form.mobileNo} onChange={e => set("mobileNo", e.target.value)} className="w-full border p-2"/>
      </FormField>

      <FormField label="Subscription Amount" error={fieldErrors.subscriptionAmount}>
        <input type="number" value={form.subscriptionAmount} onChange={e => set("subscriptionAmount", e.target.value)} className="w-full border p-2"/>
      </FormField>

      <FormField label="Document Type" error={fieldErrors.docType}>
        <select value={form.docType} onChange={e => set("docType", e.target.value)} className="w-full border p-2">
          <option value="">Select document type</option>
          <option value="GST">GST</option>
          <option value="PAN">PAN</option>
          <option value="AADHAR">AADHAR</option>
          <option value="OTHER">OTHER</option>
        </select>
      </FormField>

      <FormField label="Verification Document" error={fieldErrors.document}>
        <input type="file" accept=".pdf,.jpg,.png" onChange={e => set("document", e.target.files?.[0] || null)}/>
      </FormField>

      <button disabled={loading} onClick={submit} className="w-full bg-black text-white py-2 rounded mt-2">
        {loading ? "Processing..." : "Submit Registration"}
      </button>
    </div>
  )
}