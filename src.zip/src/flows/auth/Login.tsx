import { useState, useEffect } from "react"
import { login, bootstrapSession } from "../../engine/authEngine"
import { useNavigate } from "react-router-dom"
import { useAuthStore } from "../../store/authStore"
import { validateLogin } from "../../shared/validators"
import FormField from "../../components/FormField"
type LoginErrors={
    email?: string
    password?: string
}
export default function Login() {
  const nav = useNavigate()
  const { loading, clearMessages } = useAuthStore()

  const [form, setForm] = useState({ email: "", password: "" })
  const [fieldErrors, setFieldErrors] = useState<LoginErrors>({})

  useEffect(() => clearMessages(), [])

  const set = (k: keyof typeof form, v: string) => {
    setForm(f => ({ ...f, [k]: v }))
    setFieldErrors(e => ({ ...e, [k]: undefined }))
  }

  const submit = async () => {
    clearMessages()
    setFieldErrors({})

    const err = validateLogin(form)
    if (err) return setFieldErrors(err)

    try {
      await login(form)
      await bootstrapSession()

      const { role, status } = useAuthStore.getState()
      if (role === "OWNER" && status === "PENDING") nav("/auth/pending")
      else if (role === "OWNER") nav("/app/owner")
      else if (role === "CUSTOMER") nav("/app/customer")
      else nav("/app/admin")
    } catch {}
  }

  return (
    <div>
      <h2 className="text-lg mb-4">Login</h2>

      <FormField label="Email" error={fieldErrors.email}>
        <input
          value={form.email}
          onChange={e => set("email", e.target.value)}
          className="w-full border px-3 py-2 rounded"
        />
      </FormField>

      <FormField label="Password" error={fieldErrors.password}>
        <input
          type="password"
          value={form.password}
          onChange={e => set("password", e.target.value)}
          className="w-full border px-3 py-2 rounded"
        />
      </FormField>

      <button
        disabled={loading}
        onClick={submit}
        className="w-full bg-black text-white py-2 rounded mt-2"
      >
        {loading ? "Processing..." : "Login"}
      </button>
    </div>
  )
}