import { useNavigate } from "react-router-dom"

export default function Unauthorized() {
  const nav = useNavigate()

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow w-[350px] text-center">
        <h2 className="text-lg font-semibold mb-2 text-red-600">Access Denied</h2>
        <p className="text-sm opacity-70 mb-4">
          You are not authorized to access this page.
        </p>

        <button
          onClick={() => nav("/auth/login")}
          className="w-full bg-black text-white py-2 rounded"
        >
          Go to Login
        </button>
      </div>
    </div>
  )
}