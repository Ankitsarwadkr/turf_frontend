import { useAuthStore } from "../../store/authStore"
import { useNavigate } from "react-router-dom"

export default function Pending() {
  const { clear } = useAuthStore()
  const nav = useNavigate()

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="bg-white p-6 rounded shadow w-[350px] text-center">
        <h2 className="text-lg font-semibold mb-2">Approval Pending</h2>
        <p className="text-sm opacity-70 mb-4">
          Your owner account is under verification.
          You will be able to access the dashboard once approved.
        </p>

        <button
          onClick={() => {clear(); nav("/auth/login") }}
          className="w-full bg-black text-white py-2 rounded"
        >
          Back to Login
        </button>
      </div>
    </div>
  )
}