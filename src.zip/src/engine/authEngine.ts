import { api } from "../shared/api"
import { useAuthStore } from "../store/authStore"

const fail = (e: any) => {
  const msg = e?.response?.data?.message || "Unexpected server error"
  useAuthStore.getState().setError(msg)
  useAuthStore.getState().setLoading(false)
  throw new Error(msg)
}

// -------------------- REGISTER CUSTOMER --------------------

export const registerCustomer = async (data: any) => {
  try {
    useAuthStore.getState().setLoading(true)
    const res = await api.post("/auth/register/customer", data)
    useAuthStore.getState().setSuccess("Registration successful. Please login.")
    useAuthStore.getState().setLoading(false)
    return res
  } catch (e) {
    fail(e)
  }
}

// -------------------- REGISTER OWNER --------------------

export const registerOwner = async (fd: FormData) => {
  try {
    useAuthStore.getState().setLoading(true)
    const res = await api.post("/auth/register/owner", fd)
    useAuthStore.getState().setSuccess("Owner registered. Await admin approval.")
    useAuthStore.getState().setLoading(false)
    return res
  } catch (e) {
    fail(e)
  }
}

// -------------------- LOGIN --------------------

export const login = async (data: any) => {
  try {
    useAuthStore.getState().setLoading(true)
    const res = await api.post("/auth/login", data)

    // IMPORTANT: use real backend status
    useAuthStore.getState().setSession(res.data.role, res.data.status)

    useAuthStore.getState().setSuccess("Login successful")
    useAuthStore.getState().setLoading(false)
    return res
  } catch (e) {
    fail(e)
  }
}

// -------------------- SESSION BOOTSTRAP --------------------

export const bootstrapSession = async () => {
  try {
    const res = await api.get("/auth/me")
    useAuthStore.getState().setSession(res.data.role, res.data.status)
  } catch {
    // HARD RESET — token expired / corrupted session
    useAuthStore.getState().logout()
  }finally{
    useAuthStore.getState().markHydrated()
  }
}

// -------------------- LOGOUT --------------------

export async function logout() {
  try {
    await api.post("/auth/logout")
  } finally {
    // HARD RESET
    useAuthStore.getState().logout()
  }
}