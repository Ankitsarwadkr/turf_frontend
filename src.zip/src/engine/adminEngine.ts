import { api } from "../shared/api"

export const fetchPendingOwners = () =>
  api.get("/admin/owners/pending")

export const approveOwner = (id:number) =>
  api.put(`/admin/owners/${id}/approve`)

export const rejectOwner = (id:number, reason:string) =>
  api.put(`/admin/owners/${id}/reject`, { reason })