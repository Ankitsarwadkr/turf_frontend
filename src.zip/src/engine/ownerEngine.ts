import { api } from "../shared/api"

export const getMyTurfs = () =>
  api.get("/owners/turfs/me")

export const getTurfById=(id:number)=>
  api.get(`/owners/turfs/me/${id}`)

export const addTurf = (fd:FormData) =>
  api.post("/owners/turfs/addTurf", fd)

export const updateTurf = (id:number,data:any)=>
  api.put(`/owners/turfs/update/${id}`,data)

export const addTurfImages = (turfId: number, files: File[]) => {
  const fd = new FormData()
  files.forEach(f => fd.append("images", f))
  return api.post(`/owners/turfs/${turfId}/images`, fd)
}

export const deleteTurfImage = (turfId: number, imageId: number) =>
  api.delete(`/owners/turfs/${turfId}/images/${imageId}`)

export const deleteTurf=(id:number)=>
  api.delete(`/owners/turfs/delete/${id}`)