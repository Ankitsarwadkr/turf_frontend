export interface TurfForm {
  name: string
  address: string
  mapUrl: string
  locality: string
  city: string
  turfType: string
  available: boolean
  amenities: string
  description: string
  images: File[]
}