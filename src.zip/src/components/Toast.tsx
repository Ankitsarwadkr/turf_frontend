import { useToastStore } from "../store/toastStore"
import { useEffect } from "react"

export default function Toasts() {
  const { toasts, remove } = useToastStore()

  useEffect(() => {
    toasts.forEach(t => {
      setTimeout(() => remove(t.id), 3500)
    })
  }, [toasts])

  return (
    <div className="fixed top-4 right-4 z-[9999] space-y-2">
      {toasts.map(t => (
        <div
          key={t.id}
          className={`px-4 py-3 rounded shadow text-sm font-medium
            ${t.type === "error"
              ? "bg-red-100 text-red-700 border border-red-200"
              : "bg-green-100 text-green-700 border border-green-200"}
          `}
        >
          {t.message}
        </div>
      ))}
    </div>
  )
}