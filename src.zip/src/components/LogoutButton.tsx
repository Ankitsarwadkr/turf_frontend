import { logout } from "../engine/authEngine"
import { useNavigate } from "react-router-dom"

export default function LogoutButton() {
 return(
  <button onClick={logout} className="px-4 py-2 bg-black text-white rounded">
    Logout
  </button>
 )
}