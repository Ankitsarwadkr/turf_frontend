export default function FormField({
  label,
  error,
  children
}: {
  label: string
  error?: string
  children: React.ReactNode
}) {
  return (
    <div className="mb-3">
      <label className="block text-xs opacity-70 mb-1">{label}</label>

      {children}

      {error && (
        <div className="text-red-500 text-xs mt-1">
          {error}
        </div>
      )}
    </div>
  )
}