import { BrowserRouter, Routes, Route } from "react-router-dom"
import { useEffect, useState } from "react"
import { bootstrapSession } from "./engine/authEngine"
import ProtectedRoute from "./shared/ProtectedRoute"
import RoleGate from "./shared/RoleGate"
import AuthLayout from "./layout/AuthLayout"
import Login from "./flows/auth/Login"
import RegisterCustomer from "./flows/auth/RegisterCustomer"
import RegisterOwner from "./flows/auth/RegisterOwner"
import Pending from "./flows/auth/Pending"
import Unauthorized from "./flows/auth/Unauthorized"
import CustomerDashboard from "./flows/customer/Dashboard"
import OwnerApprovals from "./flows/admin/OwnerApprovals"
import AdminHome from "./flows/admin/AdminHome"
import AdminLayout from "./layout/AdminLayout"
import OwnerLayout from "./layout/OwnerLayout"
import OwnerHome from "./flows/owner/OwnerHome"
import OwnerTurfs from "./flows/owner/OwnerTurfs"
import OwnerTurfManage from "./flows/owner/OwnerTurfManage"
import EditTurfPage from "./flows/owner/EditTurfPage"
import Toasts from "./components/Toast"
import ManageTurfImages from "./flows/owner/ManageTurfImages"


export default function App() {
  const [ready, setReady] = useState(false)

  useEffect(() => {
    bootstrapSession().finally(() => setReady(true))
  }, [])

  if (!ready) return null

  return (
    <BrowserRouter>
    <Toasts/>
      <Routes>

        {/* AUTH WORLD */}
        <Route element={<AuthLayout />}>
          <Route path="/auth/login" element={<Login />} />
          <Route path="/auth/register/customer" element={<RegisterCustomer />} />
          <Route path="/auth/register/owner" element={<RegisterOwner />} />
          <Route path="/auth/pending" element={<Pending />} />
          <Route path="/unauthorized" element={<Unauthorized />} />
        </Route>

        {/* PROTECTED WORLD */}
       <Route element={<ProtectedRoute />}>

        <Route element={<RoleGate allow={["CUSTOMER"]} />}>
          <Route path="/app/customer" element={<CustomerDashboard />} />
        </Route>
    <Route element={<RoleGate allow={["OWNER"]} />}>
      <Route path="/app/owner" element={<OwnerLayout/>}>
        <Route index element={<OwnerHome />} />
        <Route path="turfs" element={<OwnerTurfs/>}/>
        <Route path="turfs/:turfId" element={<OwnerTurfManage/>}/>
        <Route path="turfs/:turfId/edit" element={<EditTurfPage/>}/>
        <Route path="turfs/:turfId/images" element={<ManageTurfImages/>}/>
      </Route>
    </Route>

        <Route element={<RoleGate allow={["ADMIN"]} />}>
          <Route path="/app/admin" element={<AdminLayout />}>
            <Route index element={<AdminHome />} />
            <Route path="owners" element={<OwnerApprovals />} />
          </Route>
        </Route>

    </Route>


        {/* FALLBACK */}
        <Route path="*" element={<Unauthorized />} />

      </Routes>
    </BrowserRouter>
  )
}